#include <iostream>
#include <cmath>

#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <nav_msgs/Odometry.h>

#include "plan_env/lec4.h"
#include "ego_planner/TutorialGoal.h"

using namespace std;

ros::Subscriber odom_sub;
ros::Publisher param_goal_pub;
ros::ServiceClient client;
int waypoint_num_;
double waypoints_[50][3];

double spin_rate;

// 
void OdomCallback(const nav_msgs::Odometry& msg) {
    ROS_WARN_ONCE("odom CB");
    static int way_point_count = 0;

    if (way_point_count >= waypoint_num_) {
        ROS_WARN_ONCE("all points pub");
        return;
    }
    float dist = std::sqrt(std::pow(waypoints_[way_point_count][0] - msg.pose.pose.position.x, 2) + 
                            std::pow(waypoints_[way_point_count][1] - msg.pose.pose.position.y, 2) + 
                            std::pow(waypoints_[way_point_count][2] - msg.pose.pose.position.z, 2));

    //TODO 
    /***your code for publishing drone goal***/
}

int main(int argc, char** argv) {
  ros::init(argc, argv, "exercesie2_param_node");
  ros::NodeHandle n("~");

  odom_sub = n.subscribe("/odom", 10, OdomCallback);
  param_goal_pub = n.advertise<ego_planner::TutorialGoal>("/waypoint_generator/tutorial_goal", 10);

  //TODO 
  /*your code for param reading*/
 

  n.param("/spin_rate", spin_rate, 10.0);
  ros::Duration(0.5).sleep();

  ros::Rate loop_rate(spin_rate);

  while (ros::ok()) {
    ros::spinOnce();
    loop_rate.sleep();
  }
}