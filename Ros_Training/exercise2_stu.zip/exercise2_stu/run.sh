roslaunch ego_planner simple_run.launch & sleep 1.0

roslaunch key_sim key_sim.launch & sleep 1.0

roslaunch exercise2 exercise2.launch
